from transformers import AutoTokenizer, AutoModelForCausalLM, AwqConfig
from peft import PeftModel
import torch

def merge_and_save(peft_path: str, org_model_id: str, output_model_id: str):
    tokenizer = AutoTokenizer.from_pretrained(org_model_id)
    model = AutoModelForCausalLM.from_pretrained(
        org_model_id,
        device_map = "auto",
        torch_dtype = torch.bfloat16,
        use_cache = True,
    )
    model = PeftModel.from_pretrained(model, peft_path)
    model = model.merge_and_unload()
    
    model.save_pretrained(output_model_id)
    tokenizer.save_pretrained(output_model_id)

if __name__ == "__main__":
    peft_path = "checkpoint/checkpoint-195"
    org_model_id = "Viet-Mistral/Vistral-7B-Chat"
    output_model_id = "/home/tu/Work/Agents/LLMAgents/models/SFT/Vistral-sentiment-ep5"
    
    merge_and_save(peft_path, org_model_id, output_model_id)
    

