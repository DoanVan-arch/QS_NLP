from datasets import (
    load_from_disk,
    set_caching_enabled,
    load_dataset,
    concatenate_datasets,
)
from dataclasses import dataclass
from transformers import PreTrainedTokenizerFast
import torch
from torch.utils.data import DataLoader
from typing import List

@dataclass
class Prompter:
    system_prompt: str = "Bạn là một trợ lý tiếng Việt nhiệt tình và trung thực. Hãy luôn trả lời một cách hữu ích nhất và chính xác nhất có thể, tránh việc đưa ra thông tin sai lệch."
    sentiment_prompt: str = "Hãy giúp tôi phân loại văn bản có nội dung sau đây vào một trong ba nhãn: Tiêu cực, Tích cực hoặc Trung lập./n{text}"

class DatasetBuilder:
    
    set_caching_enabled(False)
    
    def __init__(
        self,
        dataset_path: str,
        tokenizer: PreTrainedTokenizerFast,
        max_length: int = 64,
    ):
        self.tokenizer = tokenizer
        self.prompter = Prompter
        self.max_length = max_length
        
        dataset = load_from_disk(dataset_path)
        
        self.dataset = dataset.map(
            self._sentiment_items, 
            remove_columns = dataset.column_names, 
            num_proc = 8
        )
    
    @classmethod
    def get_train_dataset(cls, dataset_path: str, tokenizer: PreTrainedTokenizerFast, max_length: int = 64):
        return cls(dataset_path = dataset_path, tokenizer = tokenizer, max_length = max_length).dataset

    def _sentiment_items(self, sample):
        text = sample["text"]
        label = sample["label"]
    
        conversation = [{"role": "system", "content": self.prompter.system_prompt}]
        conversation.extend([
            {"role": "user", "content": self.prompter.sentiment_prompt.format(text = text)},
            {"role": "assistant", "content": label}
        ])
        input_ids = self.tokenizer.apply_chat_template(
            conversation,
            tokenize = True,
            add_generation_prompt = True,
        )
        if len(input_ids) > self.max_length:
            _inst_indices = len(input_ids) - 1 - input_ids[::-1].index(self.tokenizer.encode("[/INST]", add_special_tokens = False)[0])
            num_trunc_tokens = len(input_ids) - self.max_length
            input_ids = input_ids[:_inst_indices - 1 - num_trunc_tokens] + input_ids[_inst_indices - 1:]
            
        return dict(input_ids = input_ids)