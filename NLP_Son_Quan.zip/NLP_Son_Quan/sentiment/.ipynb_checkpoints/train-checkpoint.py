from dataset import *
import fire
from dataclasses import dataclass, field
from typing import List, Union
import transformers
from datasets import concatenate_datasets
from transformers import (
    AutoTokenizer,
    Trainer, 
    TrainingArguments,
)
from unsloth import FastLanguageModel
from trl import DataCollatorForCompletionOnlyLM
from huggingface_hub import login
import torch

def load_tokenizer_and_model(model_name: str, max_seq_length: int):
    login(token = "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")
    tokenizer = AutoTokenizer.from_pretrained(
        model_name, 
        use_fast = True, 
        padding_side = "right"
    )
    model, _ = FastLanguageModel.from_pretrained(
        model_name = model_name,
        max_seq_length = max_seq_length,
        dtype = None,
        load_in_4bit = True,
        use_cache = False,
    )
    model = FastLanguageModel.get_peft_model(
        model,
        r = 16, 
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha = 16,
        lora_dropout = 0.0, 
        bias = "none",   
        use_gradient_checkpointing = True,
        random_state = 3407,
        use_rslora = False,  
        loftq_config = None, 
    )
    return tokenizer, model
    
def load_train_dataset_and_collator(tokenizer, max_length: int):
    dataset_path = "/home/tu/Work/Agents/data/sentiment"
    train_dataset = DatasetBuilder.get_train_dataset(
        dataset_path = dataset_path, tokenizer = tokenizer, max_length = max_length,
    )
        
    data_collator = DataCollatorForCompletionOnlyLM(
        response_template = "[/INST]",
        tokenizer = tokenizer
    )
    return train_dataset, data_collator

def train():
    max_length = 4096
    tokenizer, model = load_tokenizer_and_model(
        model_name = "Viet-Mistral/Vistral-7B-Chat",
        max_seq_length = max_length,
    )
    train_dataset, data_collator = load_train_dataset_and_collator(
        tokenizer = tokenizer,
        max_length = max_length,
    )
    
    training_args = TrainingArguments(
        output_dir = "checkpoint",
        per_device_train_batch_size = 4,
        gradient_accumulation_steps = 32,
        weight_decay = 0.001,
        learning_rate = 2e-4,
        max_grad_norm = 1.0,
        num_train_epochs = 6,
        lr_scheduler_type = "cosine",
        warmup_ratio = 0.03,
        log_level = "info",
        logging_strategy = "steps",
        logging_steps = 5,
        save_strategy = "epoch",
        save_only_model = True,
        fp16 = not torch.cuda.is_bf16_supported(),
        bf16 = torch.cuda.is_bf16_supported(),
        optim = "adamw_torch_fused",
        report_to = "wandb",
        group_by_length = True,
        ddp_find_unused_parameters = False,
        gradient_checkpointing = True,
    )
    trainer = Trainer(
        model = model,
        tokenizer = tokenizer,
        args = training_args,
        train_dataset = train_dataset,
        data_collator = data_collator,
    )
    trainer.train()

    if trainer.is_fsdp_enabled:
      trainer.accelerator.state.fsdp_plugin.set_state_dict_type("FULL_STATE_DICT")

    trainer.save_model(training_args.output_dir)

if __name__ == "__main__":
     fire.Fire(train)
